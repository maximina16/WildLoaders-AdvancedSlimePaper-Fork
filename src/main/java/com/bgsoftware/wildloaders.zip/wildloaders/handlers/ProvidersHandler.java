package com.bgsoftware.wildloaders.handlers;

import com.bgsoftware.common.reflection.ReflectMethod;
import com.bgsoftware.wildloaders.WildLoadersPlugin;
import com.bgsoftware.wildloaders.api.hooks.ClaimsProvider;
import com.bgsoftware.wildloaders.api.hooks.SpawnersProvider;
import com.bgsoftware.wildloaders.api.hooks.TickableProvider;
import com.bgsoftware.wildloaders.api.hooks.WorldsProvider;
import com.bgsoftware.wildloaders.api.managers.ProvidersManager;
import com.bgsoftware.wildloaders.hooks.ChunksProvider;
import com.bgsoftware.wildloaders.hooks.ChunksProvider_Default;
import com.bgsoftware.wildloaders.scheduler.Scheduler;
import com.bgsoftware.wildloaders.utils.SpawnerChangeListener;
import com.google.common.base.Preconditions;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;

import javax.annotation.Nullable;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;

public final class ProvidersHandler implements ProvidersManager {

    private final WildLoadersPlugin plugin;

    private final List<ClaimsProvider> claimsProviders = new LinkedList<>();
    private final List<TickableProvider> tickableProviders = new LinkedList<>();
    private final List<WorldsProvider> worldsProviders = new LinkedList<>();
    private final List<SpawnersProvider> spawnersProviders = new LinkedList<>();

    private final ChunksProvider chunksProvider = initializeChunksProvider();

    public ProvidersHandler(WildLoadersPlugin plugin) {
        this.plugin = plugin;
        loadWorldProviders();
        Scheduler.runTask(() -> {
            loadClaimsProviders();
            loadTickableProviders();
            loadSpawnersProviders();
        });
    }

    private void loadClaimsProviders() {
        // Loading the claim providers
        if (Bukkit.getPluginManager().isPluginEnabled("Factions")) {
            if (Bukkit.getPluginManager().getPlugin("Factions").getDescription().getAuthors().contains("drtshock")) {
                Optional<ClaimsProvider> claimsProvider = createInstance("ClaimsProvider_FactionsUUID");
                claimsProvider.ifPresent(this::addClaimsProvider);
            } else {
                Optional<ClaimsProvider> claimsProvider = createInstance("ClaimsProvider_MassiveFactions");
                claimsProvider.ifPresent(this::addClaimsProvider);
            }
        }
        if (Bukkit.getPluginManager().isPluginEnabled("FactionsX")) {
            Optional<ClaimsProvider> claimsProvider = createInstance("ClaimsProvider_FactionsX");
            claimsProvider.ifPresent(this::addClaimsProvider);
        }
        if (Bukkit.getPluginManager().isPluginEnabled("SuperiorSkyblock2")) {
            Optional<ClaimsProvider> claimsProvider = createInstance("ClaimsProvider_SuperiorSkyblock");
            claimsProvider.ifPresent(this::addClaimsProvider);
        }
        if (Bukkit.getPluginManager().isPluginEnabled("Lands")) {
            Optional<ClaimsProvider> claimsProvider;
            if(isClassLoaded("me.angeschossen.lands.api.LandsIntegration")) {
                claimsProvider = createInstance("ClaimsProvider_Lands7");
            } else {
                claimsProvider = createInstance("ClaimsProvider_Lands");
            }
            claimsProvider.ifPresent(this::addClaimsProvider);
        }
        if (Bukkit.getPluginManager().isPluginEnabled("BentoBox")) {
            Optional<ClaimsProvider> claimsProvider = createInstance("ClaimsProvider_BentoBox");
            claimsProvider.ifPresent(this::addClaimsProvider);
        }
    }

    private void loadTickableProviders() {
        // Loading the tickable providers
        if (Bukkit.getPluginManager().isPluginEnabled("EpicSpawners")) {
            Plugin epicSpawners = Bukkit.getPluginManager().getPlugin("EpicSpawners");
            String version = epicSpawners.getDescription().getVersion();
            if (version.startsWith("6")) {
                Optional<TickableProvider> tickableProvider = createInstance("TickableProvider_EpicSpawners6");
                tickableProvider.ifPresent(this::addTickableProvider);
            } else if (version.startsWith("7")) {
                Optional<TickableProvider> tickableProvider = createInstance("TickableProvider_EpicSpawners7");
                tickableProvider.ifPresent(this::addTickableProvider);
            } else {
                Optional<TickableProvider> tickableProvider = createInstance("TickableProvider_EpicSpawners8");
                tickableProvider.ifPresent(this::addTickableProvider);
            }
        }
    }

    private void loadSpawnersProviders() {
        if (Bukkit.getPluginManager().isPluginEnabled("SpawnerLegacy")) {
            Optional<SpawnersProvider> spawnersProvider;
            if (isClassLoaded("mc.rellox.spawnerlegacyapi.SLAPI")) {
                spawnersProvider = createInstance("SpawnersProvider_SpawnerLegacy2");
            } else {
                spawnersProvider = createInstance("SpawnersProvider_SpawnerLegacy");
            }
            spawnersProvider.ifPresent(this::addSpawnersProvider);
        }
    }

    private void loadWorldProviders() {
        Optional<WorldsProvider> worldsProvider;

        if (isClassLoaded("com.infernalsuite.aswm.api.SlimePlugin")) {
            worldsProvider = createInstanceSilently("WorldsProvider_AdvancedSlimePaper");
        } else if (isClassLoaded("com.grinderwolf.swm.nms.world.AbstractSlimeNMSWorld")) {
            worldsProvider = createInstanceSilently("WorldsProvider_AdvancedSlimeWorldManager");
        } else {
            worldsProvider = createInstanceSilently("WorldsProvider_SlimeWorldManager");
        }

        worldsProvider.ifPresent(this::addWorldsProvider);
    }

    @Override
    public void addClaimsProvider(ClaimsProvider claimsProvider) {
        Preconditions.checkNotNull(claimsProvider, "claimsProvider cannot be null");
        claimsProviders.add(claimsProvider);
    }

    @Override
    public void addSpawnersProvider(SpawnersProvider spawnersProvider) {
        Preconditions.checkNotNull(spawnersProvider, "spawnersProvider cannot be null");
        spawnersProviders.add(spawnersProvider);
        SpawnerChangeListener.CALLBACK = this::setSpawnerRequiredRange;
    }

    @Override
    public void addTickableProvider(TickableProvider tickableProvider) {
        Preconditions.checkNotNull(tickableProvider, "tickableProvider cannot be null");
        tickableProviders.add(tickableProvider);
    }

    @Override
    public void addWorldsProvider(WorldsProvider worldsProvider) {
        Preconditions.checkNotNull(worldsProvider, "worldsProvider cannot be null");
        worldsProviders.add(worldsProvider);
    }

    public boolean hasChunkAccess(UUID player, World world, int chunkX, int chunkZ) {
        for (ClaimsProvider claimsProvider : claimsProviders) {
            if (claimsProvider.hasClaimAccess(player, world, chunkX, chunkZ))
                return true;
        }

        return false;
    }

    public void tick(List<Chunk> chunks) {
        tickableProviders.forEach(tickableProvider -> tickableProvider.tick(chunks));
    }

    public void setSpawnerRequiredRange(Location spawnerLocation, int requiredRange) {
        for (SpawnersProvider spawnersProvider : this.spawnersProviders) {
            spawnersProvider.setSpawnerRequiredRange(spawnerLocation, requiredRange);
        }
    }

    @Nullable
    public World loadWorld(String worldName) {
        for (WorldsProvider worldsProvider : this.worldsProviders) {
            World loadedWorld = worldsProvider.loadWorld(worldName);
            if (loadedWorld != null)
                return loadedWorld;
        }

        return null;
    }

    public void loadChunk(World world, int chunkX, int chunkZ, Consumer<Chunk> consumer) {
        this.chunksProvider.loadChunk(world, chunkX, chunkZ, consumer);
    }

    private ChunksProvider initializeChunksProvider() {
        Optional<ChunksProvider> chunksProvider = Optional.empty();
        if (new ReflectMethod<>(World.class, "getChunkAtAsync", int.class, int.class).isValid()) {
            chunksProvider = createInstance("ChunksProvider_Paper");
        }
        return chunksProvider.orElseGet(ChunksProvider_Default::new);
    }

    private static boolean isClassLoaded(String clazz) {
        try {
            Class.forName(clazz);
            return true;
        } catch (ClassNotFoundException error) {
            return false;
        }
    }

    private <T> Optional<T> createInstanceSilently(String className) {
        try {
            return createInstance(className);
        } catch (Throwable error) {
            return Optional.empty();
        }
    }

    private <T> Optional<T> createInstance(String className) {
        try {
            Class<?> clazz = Class.forName("com.bgsoftware.wildloaders.hooks." + className);
            try {
                Method compatibleMethod = clazz.getDeclaredMethod("isCompatible");
                if (!(boolean) compatibleMethod.invoke(null))
                    return Optional.empty();
            } catch (Exception ignored) {
            }

            try {
                Constructor<?> constructor = clazz.getConstructor(WildLoadersPlugin.class);
                // noinspection unchecked
                return Optional.of((T) constructor.newInstance(plugin));
            } catch (Exception error) {
                // noinspection unchecked
                return Optional.of((T) clazz.newInstance());
            }
        } catch (ClassNotFoundException ignored) {
            return Optional.empty();
        } catch (Exception error) {
            error.printStackTrace();
            return Optional.empty();
        }
    }

}
